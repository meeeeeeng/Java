
public class midterm05 {

	
	
	public void Sound(){
		System.out.println("����");
		
	}
}
