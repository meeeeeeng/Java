
public class cat extends midterm05 {


	public void Sound(){
		System.out.println("�߿�");
		
	}
}

