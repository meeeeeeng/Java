
public class Test04 {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub
		
		midterm04 obj1=new midterm04("A3","seoul");
		midterm04 obj2=new midterm04("busan");
		midterm04 obj3=new midterm04("A3","china");

		
		int num=midterm04.getNumberofCars();
		System.out.println(num+"��");
		midterm04.ShowNumberofCars();
	}

}
