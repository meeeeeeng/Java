
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		midterm03 obj= new midterm03();
		obj.sum(10,20,30);
		obj.sum(10,20);
		

	}

}
