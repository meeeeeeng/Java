
public class dog extends midterm05 {
	public void Sound(){
		System.out.println("�۸�");
		
}}
